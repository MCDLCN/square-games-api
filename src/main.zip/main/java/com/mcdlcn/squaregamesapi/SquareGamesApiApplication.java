package com.mcdlcn.squaregamesapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SquareGamesApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SquareGamesApiApplication.class, args);
	}

}
